/********************************************************************************************
* MOD-NAME      : Helpers.h
* LONG-NAME     : 
*
* AUTHOR        : Martin Ziacek (Martin.Ziacek@pobox.sk)
* DEPARTMENT    : 
* TELEPHONE     : 
* CREATION-DATE : 09/05/2001 18:00:00
* SP-NO         : 
* FUNCTION      : 
* 
*********************************************************************************************/
#ifndef __HELPERS_H__
#define __HELPERS_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// debug functions

void UsrDump(TCHAR *msg,BYTE *pData, int len);
CString GetDumpString(BYTE *pData, int len);
void DumpErrorCode(DWORD dwErrCode, DWORD dwLine , char *szFileName);
BOOL GetErrorDescription( DWORD error_code, CString& error_string );

inline TCHAR GetPrintCharOrDot(TCHAR c)
{
	if (_istprint(c)) {
		return c;
	} else {
		return (TCHAR)'.';
	}
}

#ifdef _DEBUG
#define DUMP				::UsrDump
#else
#define DUMP              1 ? (void)0 : ::UsrDump
#endif

#endif //__HELPERS_H__
