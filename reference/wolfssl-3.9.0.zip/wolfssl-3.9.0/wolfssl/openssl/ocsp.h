/* ocsp.h for libcurl */
